import React,{useState} from "react";

const cards = {"MGT": {"name": "MANAGEMENT", "tasks": 42, "critical": 5}, "STR": {"name": "STORE", "tasks": 38, "critical": 4}, "PUR": {"name": "PURCHASE & STOCK", "tasks": 36, "critical": 6}, "MKT": {"name": "MARKETING", "tasks": 41, "critical": 3}, "CRT": {"name": "CREATIVE", "tasks": 28, "critical": 2}, "MPL": {"name": "MARKETPLACE", "tasks": 33, "critical": 5}, "IT": {"name": "IT & SYSTEMS", "tasks": 31, "critical": 4}, "ISO": {"name": "ISO & DCC", "tasks": 27, "critical": 3}, "AI": {"name": "AI", "tasks": 19, "critical": 2}, "RPT": {"name": "REPORT & DASHBOARD", "tasks": 0, "critical": 0}};
const cardOrder=["MGT","STR","PUR","MKT","CRT","MPL","IT","ISO","AI","RPT"];
const iconPath=code=>`/assets/${code.toLowerCase()}-icon.png`;

export default function App(){
  const [active,setActive]=useState(null);

  if(active){
    const c=cards[active];
    return <div className="detail-page">
      <header className="detail-head">
        <button className="back" onClick={()=>setActive(null)}>← HOME</button>
        <div>
          <div className="eyebrow">{active}</div>
          <h1>{c.name}</h1>
          <p>Department workspace / Project Control Center</p>
        </div>
      </header>
      <main className="detail-main">
        <section className="metric-row">
          <Metric label="Total Tasks" value={c.tasks || "—"}/>
          <Metric label="Critical" value={c.critical || "—"} accent/>
          <Metric label="Status" value={active==="RPT"?"Dashboard":"Working Draft"}/>
        </section>
        <section className="work-panel">
          <h2>{active==="RPT"?"REPORT & DASHBOARD":"PROJECT / ACTION VIEW"}</h2>
          <p>หน้ารายละเอียดนี้เป็น Workspace จริงที่กดเข้าจากหน้า Approved UI แล้ว ไม่ใช่ภาพพื้นหลัง</p>
          <div className="placeholder">กำลังเชื่อม Project & Action Master / UAT Data</div>
        </section>
      </main>
    </div>
  }

  return <div className="app-shell">
    <section className="left-hero">
      <div className="brand-row">
        <img src="/assets/allaboutpet-logo.png" className="logo"/>
        <div><div className="internal">INTERNAL PROJECT SYSTEM</div><div className="subbrand">Project Control Center</div></div>
      </div>

      <div className="hero-title">
        <div>PROJECT</div><div className="red">CONTROL</div><div>CENTER</div>
      </div>

      <div className="center-tag"><span>🐾</span>ศูนย์ควบคุมแผนงานและการดำเนินงานขององค์กร</div>

      <div className="summary-card">
        <div className="summary-item"><div className="round">📅</div><div><b>ข้อมูลอัปเดตล่าสุด</b><br/>28 สิงหาคม 2569<br/><span className="redtxt">07:55 AM</span></div></div>
        <div className="divider"></div>
        <div className="summary-item"><div className="round">📋</div><div><b>รวมงานทั้งหมด</b><br/><span className="big redtxt">295</span><br/>Tasks</div></div>
      </div>

      <div className="left-bottom">
        <div><b>🎯 เป้าหมายองค์กร</b><ul><li>สร้างการเติบโตอย่างยั่งยืน</li><li>มอบคุณค่าให้ลูกค้าและสัตว์เลี้ยง</li><li>ทีมงานมีความสุขและเติบโตไปด้วยกัน</li></ul></div>
        <div><b>🐾 ปรัชญาการทำงานของเรา</b><p className="quote">“We don't only look at sales;<br/>we look at how much trust<br/>you create with customers.”</p></div>
      </div>
    </section>

    <section className="right-panel">
      <div className="panel-title">เข้าสู่ระบบงานของแต่ละฝ่าย</div>
      <div className="cards-grid">
        {cardOrder.map((code,i)=>{
          const c=cards[code];
          return <article key={code} className="dept-card">
            <img src={iconPath(code)} className="dept-icon"/>
            <h3>{c.name}</h3>
            <div className="dots">······ • ······</div>
            {code!=="RPT" ? <div className="counts">
              <div><span>Total Tasks</span><b>{c.tasks}</b></div>
              <div><span>Critical</span><b className="redtxt">{c.critical}</b></div>
            </div> : <div className="report-copy">รายงานสรุปผล<br/>การดำเนินงานและ<br/>Dashboard ภาพรวม</div>}
            <button className={i%2===0?"open redbtn":"open"} onClick={()=>setActive(code)}>OPEN ›</button>
          </article>
        })}
      </div>
    </section>

    <section className="bottom-strip">
      <div><b>LEGEND : ระดับความสำคัญ</b><div className="legend">🔺 Critical &nbsp; 🟧 High &nbsp; 🟨 Medium &nbsp; 🟩 Low</div></div>
      <div><b>🎯 เป้าหมายองค์กร</b><div>• สร้างการเติบโตอย่างยั่งยืน<br/>• มอบคุณค่าให้ลูกค้าและสัตว์เลี้ยง</div></div>
      <div><b>🐾 ปรัชญาการทำงานของเรา</b><div className="quote smallq">“We don't only look at sales;<br/>we look at how much trust<br/>you create with customers.”</div></div>
      <div><b>QUICK LINK</b><div>• Annual Plan (แผนประจำปี)<br/>• CAPA & Daily Management<br/>• Document Control Master<br/>• Monthly Business Review</div></div>
    </section>

    <footer>ALL ABOUT PET &nbsp;&nbsp; | &nbsp;&nbsp; PROJECT CONTROL CENTER &nbsp;&nbsp; | &nbsp;&nbsp; POWERED BY TEAMWORK & TRUST</footer>
  </div>
}

function Metric({label,value,accent}){return <div className="metric"><span>{label}</span><strong className={accent?"redtxt":""}>{value}</strong></div>}
